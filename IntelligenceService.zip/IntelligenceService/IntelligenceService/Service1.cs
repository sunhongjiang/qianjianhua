﻿using System;
using System.Configuration;
using System.Diagnostics;

using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Text;
using System.Threading;

using System.Web.Script.Serialization;

namespace IntelligenceService
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            LogHelper.LogInfo("服务开启。。");


            BuildSocket();
        }

        protected override void OnStop()
        {
            LogHelper.LogInfo("服务结束。。");
            if (thread != null)
                thread.Abort();
        }

        private Thread thread;

        public string GetLocalIP()
        {
            try
            {
                string HostName = Dns.GetHostName(); //得到主机名
                IPHostEntry IpEntry = Dns.GetHostEntry(HostName);
                for (int i = 0; i < IpEntry.AddressList.Length; i++)
                {
                    //从IP地址列表中筛选出IPv4类型的IP地址
                    //AddressFamily.InterNetwork表示此IP为IPv4,
                    //AddressFamily.InterNetworkV6表示此地址为IPv6类型
                    if (IpEntry.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
                    {
                        return IpEntry.AddressList[i].ToString();
                    }
                }
                return "";
            }
            catch (Exception ex)
            {
                LogHelper.LogError("getip:" + ex.Message);
                return "";
            }
        }

        private void BuildSocket()
        {
            try
            {
                //var port = ConfigurationManager.AppSettings["port"];
                //点击开始监听时 在服务端创建一个负责监听IP和端口号的Socket
                Socket socketWatch = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                //IPAddress ip = IPAddress.Any;
                IPAddress ip = IPAddress.Parse(GetLocalIP());
                //创建对象端口
                IPEndPoint point = new IPEndPoint(ip, 9988);

                socketWatch.Bind(point);//绑定端口号
                LogHelper.LogInfo("监听成功");
                socketWatch.Listen(10);//设置监听

                //创建监听线程
                thread = new Thread(Listen);
                thread.IsBackground = true;
                thread.Start(socketWatch);
            }
            catch (Exception ex)
            {
                LogHelper.LogError("异常：" + ex.Message);
            }
        }

        private Socket socketSend;
        private void Listen(object o)
        {
            try
            {
                Socket socketWatch = o as Socket;
                while (true)
                {
                    socketSend = socketWatch.Accept();//等待接收客户端连接

                    LogHelper.LogInfo(socketSend.RemoteEndPoint.ToString() + ":" + "连接成功!");
                    LogHelper.LogInfo("开始接受消息----");
                    //开启一个新线程，执行接收消息方法
                    Thread r_thread = new Thread(Received);
                    r_thread.IsBackground = true;
                    r_thread.Start(socketSend);
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogError("异常：" + ex.Message);
            }
        }

        private void Received(object o)
        {
            try
            {
                Socket socketRecived = o as Socket;
                while (true)
                {
                    //客户端连接服务器成功后，服务器接收客户端发送的消息
                    byte[] buffer = new byte[1024 * 1024 * 3];
                    //实际接收到的有效字节数
                    int len = socketRecived.Receive(buffer);
                    if (len == 0)
                    {
                        break;
                    }
                    string str = Encoding.UTF8.GetString(buffer, 0, len);
                    LogHelper.LogInfo("客户端消息----" + str);

                    JavaScriptSerializer js = new JavaScriptSerializer();
                    ClientEntity clienEntity = null;
                    try
                    {
                        clienEntity = js.Deserialize<ClientEntity>(str);
                        if (clienEntity != null)
                        {
                            if (clienEntity.Type == 0)
                            {
                                Interop.CreateProcess("iexplore.exe", ConfigurationManager.AppSettings["iePath"], clienEntity.Url);
                            }
                            else
                            {
                                var arr = Process.GetProcessesByName("iexplore");
                                foreach (var item in arr)
                                {

                                    item.Kill();

                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        LogHelper.LogError("异常：" + ex.Message);
                    }

                }
            }
            catch (Exception ex)
            {
                LogHelper.LogError("异常：" + ex.Message);
            }
        }
    }
}
